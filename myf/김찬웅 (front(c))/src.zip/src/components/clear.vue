<template>
   <div>짠</div>
</template>

<script>
export default {
    
}
</script>